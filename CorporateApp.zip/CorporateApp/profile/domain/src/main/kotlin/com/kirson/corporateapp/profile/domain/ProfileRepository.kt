package com.kirson.corporateapp.profile.domain

interface ProfileRepository {

}
