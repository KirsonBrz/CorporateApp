package com.kirson.corporateapp.profile.domain

import kotlinx.coroutines.flow.Flow
import com.kirson.corporateapp.core.domain.entity.LceState

interface ProfileModel {

}