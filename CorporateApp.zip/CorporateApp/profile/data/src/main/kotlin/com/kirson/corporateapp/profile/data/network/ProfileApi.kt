package com.kirson.corporateapp.profile.data.network


internal interface ProfileApi {

}