package com.kirson.corporateapp.orders.domain

import com.kirson.corporateapp.core.domain.BaseUseCase
import com.kirson.corporateapp.core.domain.entity.LceState
import com.kirson.corporateapp.core.domain.entity.Order
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.flow.Flow
import javax.inject.Inject

internal class OrdersModelImpl @Inject constructor(
    scope: CoroutineScope,
    private val repository: OrdersRepository,
) : BaseUseCase<OrdersModelImpl.State>(scope, State()), OrdersModel {

  data class State(
      val userIdentificationState: LceState = LceState.None,
      val loginState: LceState = LceState.None
  )


  override val orders: Flow<List<Order>>
    get() = repository.getOrders()
}