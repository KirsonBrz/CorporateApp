package com.kirson.corporateapp.orders.domain

import kotlinx.coroutines.flow.Flow
import com.kirson.corporateapp.core.domain.entity.LceState
import com.kirson.corporateapp.core.domain.entity.Order

interface OrdersModel {
  val orders: Flow<List<Order>>
}