package com.kirson.corporateapp.orders.domain

import com.kirson.corporateapp.core.domain.entity.Order
import kotlinx.coroutines.flow.Flow

interface OrdersRepository {
  fun getOrders(): Flow<List<Order>>
}
