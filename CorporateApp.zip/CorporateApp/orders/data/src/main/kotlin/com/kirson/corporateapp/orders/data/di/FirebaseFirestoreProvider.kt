package com.kirson.corporateapp.orders.data.di

import com.google.firebase.firestore.FirebaseFirestore
import javax.inject.Inject
import javax.inject.Provider

//internal class FirebaseFirestoreProvider @Inject constructor(
//    private val fireStore: FirebaseFirestore,
//) : Provider<FirebaseFirestore> {
//  override fun get(): FirebaseFirestore {
//    return fireStore.
//  }
//}