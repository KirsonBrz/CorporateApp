package com.kirson.corporateapp.orders.data.network


internal interface OrdersApi {

}