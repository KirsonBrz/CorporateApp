package com.kirson.corporateapp.orders.data

import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.ktx.firestore
import com.google.firebase.firestore.ktx.toObject
import com.google.firebase.ktx.Firebase
import com.kirson.corporateapp.core.data.storage.persistence.TokensPersistence
import com.kirson.corporateapp.core.domain.entity.Department
import com.kirson.corporateapp.core.domain.entity.Order
import com.kirson.corporateapp.core.domain.entity.OrderId
import com.kirson.corporateapp.orders.data.network.OrderResponse
import com.kirson.corporateapp.orders.data.network.OrdersApi
import com.kirson.corporateapp.orders.domain.OrdersRepository
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow
import kotlinx.coroutines.flow.flow
import javax.inject.Inject

internal class OrdersRepositoryImpl @Inject constructor(

) : OrdersRepository {
  val firestore: FirebaseFirestore = FirebaseFirestore.getInstance()
  @OptIn(ExperimentalCoroutinesApi::class)
  override fun getOrders(): Flow<List<Order>> {
    return flow {
      val collection = firestore.collection("orders")
      collection
          .get()
          .addOnSuccessListener { result ->
            for (document in result) {
              orders.add(document.toObject())
            }
          }
    }
  }
  val orders = mutableListOf(
      Order(
          id = "1",
          departmentType = Department.DepartmentType.ServiceDepartment,
          description = "desc"
      )
  )
}
