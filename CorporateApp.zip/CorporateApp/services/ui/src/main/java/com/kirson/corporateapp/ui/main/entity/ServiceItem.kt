package com.kirson.corporateapp.ui.main.entity

import com.kirson.corporateapp.ui.entity.ServiceItemId

data class ServiceItem(
    val id: ServiceItemId,
    val icon: Int,
    val name: String,
)