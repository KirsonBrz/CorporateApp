package com.kirson.corporateapp.ui.main

import com.kirson.corporateapp.services.domain.ServicesModel
import com.kirson.corporateapp.core.coroutine.BasePresenter
import com.kirson.corporateapp.routing.AppFlow
import com.kirson.corporateapp.services.ui.R
import com.kirson.corporateapp.ui.main.entity.ServiceItem
import com.kirson.corporateapp.ui.entity.ServiceItemId
import com.kirson.corporateapp.ui.main.ServicesScreen.ViewIntents
import com.kirson.corporateapp.ui.main.ServicesScreen.ViewState
import com.kirson.corporateapp.ui.main.entity.ActualInfoItem
import com.kirson.corporateapp.ui.main.entity.AtcualInfoItemId
import com.kirson.corporateapp.ui.mappers.toService
import ru.dimsuz.unicorn.coroutines.MachineDsl
import javax.inject.Inject

internal class ServicesPresenter @Inject constructor(
  private val servicesModel: ServicesModel,
  private val coordinator: AppFlow.Coordinator,
) : BasePresenter<ViewState, ViewIntents, Unit>() {

  override fun MachineDsl<ViewState, Unit>.buildMachine() {
    initial = createInitialState() to null

    onEach(intent(ViewIntents::navigateOnBack)) {
      action { _, _, _ ->
        coordinator.handleEvent(AppFlow.Event.ServicesDismissed)
      }
    }

    onEach(intent(ViewIntents::switchSection)) {
      action { _, _, section ->
        coordinator.handleEvent(AppFlow.Event.Switch(section))
      }
    }

    onEach(intent(ViewIntents::onItemClick)) {
      action { _, _, id ->
        coordinator.handleEvent(AppFlow.Event.ServiceInfoRequested(id.toService()))
      }
    }

    onEach(intent(ViewIntents::dismissError)) {
      transitionTo { state, _ ->
        state.copy(errorMessage = null)
      }
    }
  }

  private fun createInitialState(): ViewState{
    return ViewState(
        serviceItems = listOf(
            ServiceItem(
                id = ServiceItemId(
                    value = "1"
                ),
                name = "Документы",
                icon = R.drawable.ic_check_24
            ),
            ServiceItem(
                id = ServiceItemId(
                    value = "2"
                ),
                name = "Заявка специалисту",
                icon = R.drawable.ic_check_24
            ),
            ServiceItem(
                id = ServiceItemId(
                    value = "3"
                ),
                name = "Что-то",
                icon = R.drawable.ic_check_24
            ),
            ServiceItem(
                id = ServiceItemId(
                    value = "4"
                ),
                name = "Тоже",
                icon = R.drawable.ic_check_24
            ),
            ServiceItem(
                id = ServiceItemId(
                    value = "5"
                ),
                name = "Документы",
                icon = R.drawable.ic_check_24
            ),



            ServiceItem(
                id = ServiceItemId(
                    value = "6"
                ),
                name = "Что-то",
                icon = R.drawable.ic_check_24
            ),
            ServiceItem(
                id = ServiceItemId(
                    value = "7"
                ),
                name = "Тоже",
                icon = R.drawable.ic_check_24
            ),
            ServiceItem(
                id = ServiceItemId(
                    value = "8"
                ),
                name = "Документы",
                icon = R.drawable.ic_check_24
            ),
            ServiceItem(
                id = ServiceItemId(
                    value = "9"
                ),
                name = "Что-то",
                icon = R.drawable.ic_check_24
            ),
            ServiceItem(
                id = ServiceItemId(
                    value = "10"
                ),
                name = "Тоже",
                icon = R.drawable.ic_check_24
            ),
            ServiceItem(
                id = ServiceItemId(
                    value = "11"
                ),
                name = "Документы",
                icon = R.drawable.ic_check_24
            ),
        ),
        actualInfoItems = listOf(
            ActualInfoItem(
                id = AtcualInfoItemId(
                    value = "1"
                ),
                text = "Рубль резко ослаб после внепланового снижения ключевой ставки",
                background = R.drawable.money
            ),
            ActualInfoItem(
                id = AtcualInfoItemId(
                    value = "2"
                ),
                text = "Жителей Чувашии ждет повышение пенсии и минимальной оплаты труда",
                background = R.drawable.bank
            ),
            ActualInfoItem(
                id = AtcualInfoItemId(
                    value = "3"
                ),
                text = "Рубль резко ослаб после внепланового снижения ключевой ставки",
                background = R.drawable.money
            ),
            ActualInfoItem(
                id = AtcualInfoItemId(
                    value = "4"
                ),
                text = "Рубль резко ослаб после внепланового снижения ключевой ставки",
                background = R.drawable.money
            ),
        )
    )
  }
}
