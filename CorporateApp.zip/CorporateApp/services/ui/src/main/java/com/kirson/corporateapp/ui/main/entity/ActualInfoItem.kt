package com.kirson.corporateapp.ui.main.entity

data class ActualInfoItem(
    val id: AtcualInfoItemId,
    val text: String,
    val background: Int
)