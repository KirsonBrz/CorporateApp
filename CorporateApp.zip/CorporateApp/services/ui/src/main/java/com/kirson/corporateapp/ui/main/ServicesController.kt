package com.kirson.corporateapp.ui.main

import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.GridCells
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.LazyVerticalGrid
import androidx.compose.foundation.lazy.items
import androidx.compose.material.SnackbarHost
import androidx.compose.material.SnackbarHostState
import androidx.compose.material.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.google.accompanist.insets.navigationBarsWithImePadding
import com.google.accompanist.insets.statusBarsPadding
import com.kirson.corporateapp.services.ui.R
import com.kirson.corporateapp.ui.component.ActualIfoComponent
import com.kirson.corporateapp.ui.component.ServiceItemCard
import com.kirson.corporateapp.ui.core.uikit.KodeBankBaseController
import com.kirson.corporateapp.ui.core.uikit.component.BottomBar
import com.kirson.corporateapp.ui.core.uikit.component.ErrorSnackbar
import com.kirson.corporateapp.ui.core.uikit.component.HorizontalDivider
import com.kirson.corporateapp.ui.core.uikit.component.TopAppBar
import com.kirson.corporateapp.ui.core.uikit.component.entity.MainSection
import com.kirson.corporateapp.ui.core.uikit.theme.AppTheme
import com.kirson.corporateapp.ui.main.entity.ServiceItem
import com.kirson.corporateapp.ui.main.ServicesScreen.ErrorMessage
import com.kirson.corporateapp.ui.main.ServicesScreen.ViewIntents
import com.kirson.corporateapp.ui.main.ServicesScreen.ViewState
import com.kirson.corporateapp.ui.main.entity.ActualInfoItem

internal class ServicesController : KodeBankBaseController<ViewState, ViewIntents>() {

  override fun createConfig(): Config<ViewIntents> {
    return object : Config<ViewIntents> {
      override val intentsConstructor = ::ViewIntents
    }
  }

  override fun handleBack(): Boolean {
    intents.navigateOnBack()
    return true
  }

  @ExperimentalFoundationApi
  @Composable
  override fun ScreenContent(state: ViewState) {
    Box(
        modifier = Modifier
            .statusBarsPadding()
            .navigationBarsWithImePadding(),
    ) {
      Column(
          horizontalAlignment = Alignment.CenterHorizontally,
      ) {
        TopAppBar(
            modifier = Modifier.background(AppTheme.colors.backgroundPrimary),
            leftContent = {
              Text(
                  modifier = Modifier.padding(horizontal = 24.dp),
                  text = "Сервисы",
                  style = AppTheme.typography.title
              )
            },
            centerContent = {
            },
            rightContent = {}
        )
        Spacer(modifier = Modifier.height(16.dp))
        Text(
            modifier = Modifier
                .padding(horizontal = 24.dp)
                .align(Alignment.Start),
            text = "Актуальное",
            style = AppTheme.typography.bodyRegular,
            textAlign = TextAlign.Start,
        )
        Box(
            modifier = Modifier
                .weight(0.4f),
            contentAlignment = Alignment.Center,
        ) {
          ActualInfoItems(
              items = state.actualInfoItems
          )
        }
        Spacer(modifier = Modifier.height(28.dp))
        Text(
            modifier = Modifier
                .padding(horizontal = 24.dp)
                .align(Alignment.Start),
            text = "Сервисы",
            style = AppTheme.typography.bodyRegular,
            textAlign = TextAlign.Start,
        )
        Spacer(modifier = Modifier.height(8.dp))
        Box(
            modifier = Modifier
               // .fillMaxSize()
                .weight(1f),
            contentAlignment = Alignment.TopCenter,
        ) {
          Column(
              modifier = Modifier
          ) {
            ServiceGrid(
                services = state.serviceItems
            )
          }
        }
        ServicesBottomBar()
      }
      Snackbar(
          modifier = Modifier.align(Alignment.BottomCenter),
          message = state.errorMessage?.name(),
          onDismiss = intents.dismissError,
      )
    }
  }

  @Composable
  fun ActualInfoItems(
      items: List<ActualInfoItem>
  ) {
    LazyRow(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 12.dp),
    ) {
      items(items) { item ->
        ActualIfoComponent(
            text = item.text,
            background = item.background
        )
      }

    }
  }

  @ExperimentalFoundationApi
  @Composable
  fun ServiceGrid(
      services: List<ServiceItem>
  ) {
    LazyVerticalGrid(
        cells = GridCells.Fixed(2),
        // content padding
        contentPadding = PaddingValues(
            start = 12.dp,
            end = 12.dp,
            bottom = 16.dp
        ),
        content = {
          items(services) { service ->
            ServiceItemCard(
                icon = painterResource(id = service.icon),
                title = service.name,
                onClick = { intents.onItemClick(service.id) },
                color = AppTheme.colors.contendAccentPrimary
            )
          }
        }
    )
  }

  @Composable
  private fun ServicesBottomBar() {
    BottomBar(
        activeTab = MainSection.Services,
        onTabClick = intents.switchSection,
    )
  }

  @Composable
  private fun Snackbar(
      modifier: Modifier = Modifier,
      message: String?,
      onDismiss: () -> Unit,
  ) {
    val snackbarHostState = remember { SnackbarHostState() }

    if (message != null) {
      LaunchedEffect(message) {
        snackbarHostState.showSnackbar(message = message)
        onDismiss()
      }
    }

    SnackbarHost(
        modifier = modifier,
        hostState = snackbarHostState,
        snackbar = { snackBarData ->
          ErrorSnackbar(Modifier.padding(16.dp), snackBarData.message)
        }
    )
  }
}

@Composable
private fun ErrorMessage.name(): String {
  return when (this) {
    ErrorMessage.LoginError -> stringResource(id = R.string.error_something_went_wrong_title)
  }
}
