package com.kirson.corporateapp.ui.documents.entity

data class Document(
    val id: DocumentItemId,
    val title: String,
    val description: String
)