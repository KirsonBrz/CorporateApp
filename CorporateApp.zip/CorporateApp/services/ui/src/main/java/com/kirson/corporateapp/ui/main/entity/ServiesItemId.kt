package com.kirson.corporateapp.ui.entity

@JvmInline
value class ServiceItemId (val value: String)