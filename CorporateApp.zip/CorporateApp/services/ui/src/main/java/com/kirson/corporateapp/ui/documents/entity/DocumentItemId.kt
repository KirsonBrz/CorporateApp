package com.kirson.corporateapp.ui.documents.entity

@JvmInline
value class DocumentItemId (val value: String)