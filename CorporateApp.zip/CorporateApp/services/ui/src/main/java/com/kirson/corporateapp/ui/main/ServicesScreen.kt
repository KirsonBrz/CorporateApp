package com.kirson.corporateapp.ui.main

import androidx.compose.runtime.Immutable
import com.kirson.corporateapp.core.BaseViewIntents
import com.kirson.corporateapp.ui.core.uikit.component.entity.MainSection
import com.kirson.corporateapp.ui.main.entity.ServiceItem
import com.kirson.corporateapp.ui.entity.ServiceItemId
import com.kirson.corporateapp.ui.main.entity.ActualInfoItem

internal object ServicesScreen {
  class ViewIntents : BaseViewIntents() {
    val navigateOnBack = intent(name = "navigateOnBack")
    val onItemClick = intent<ServiceItemId>(name = "onItemClick")
    val switchSection = intent<MainSection>(name = "switchSection")
    val dismissError = intent(name = "dismissError")
  }

  @Immutable
  data class ViewState(
      val serviceItems: List<ServiceItem> = emptyList(),
      val actualInfoItems: List<ActualInfoItem> = emptyList(),
      val errorMessage: ErrorMessage? = null
  )

  sealed class ErrorMessage {
    object LoginError : ErrorMessage()
  }
}
