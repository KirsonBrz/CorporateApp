package com.kirson.corporateapp.ui.main.entity

@JvmInline
value class AtcualInfoItemId (val value: String)