package com.kirson.corporateapp.services.domain

import com.kirson.corporateapp.core.domain.entity.Order
import kotlinx.coroutines.flow.Flow

interface ServicesRepository {
  fun createOrder(): Flow<Order>
}
