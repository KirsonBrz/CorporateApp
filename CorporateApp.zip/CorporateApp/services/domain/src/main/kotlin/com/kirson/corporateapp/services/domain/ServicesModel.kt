package com.kirson.corporateapp.services.domain

import kotlinx.coroutines.flow.Flow
import com.kirson.corporateapp.core.domain.entity.LceState
import com.kirson.corporateapp.core.domain.entity.Order
import com.kirson.corporateapp.ui.core.uikit.component.entity.MainSection

interface ServicesModel {
  suspend fun createOrder(order: Order)
  val orders: Flow<List<Order>>
}