package com.kirson.corporateapp.services.domain

import kotlinx.coroutines.CoroutineScope

import com.kirson.corporateapp.core.domain.BaseUseCase
import com.kirson.corporateapp.core.domain.entity.Department
import com.kirson.corporateapp.core.domain.entity.LceState
import com.kirson.corporateapp.core.domain.entity.Order
import com.kirson.corporateapp.core.domain.entity.OrderId
import com.kirson.corporateapp.core.routing.coordinator.BaseFlowCoordinator
import com.kirson.corporateapp.ui.core.uikit.component.entity.MainSection
import com.kirson.corporateapp.ui.core.uikit.component.entity.MainSectionNavigationMediator
import kotlinx.coroutines.flow.*
import javax.inject.Inject

 class ServicesModelImpl @Inject constructor(
  scope: CoroutineScope,
  private val repository: ServicesRepository,
) : BaseUseCase<ServicesModelImpl.State>(scope, State()), ServicesModel {

  data class State(
    val order: Order? = null,
    val loginState: LceState = LceState.None
  )

  override suspend fun createOrder(order: Order) {
    setState {
      copy(
          order = order
      )
    }
    repository.createOrder()
  }

   override val orders: Flow<List<Order>>
     get() = TODO("Not yet implemented")

//  override val orders: Flow<State> = stateFlow.map {
//    val order = orders.first()
//    it.copy(
//        order = order.order
//    )
//  }

}