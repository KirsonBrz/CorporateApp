package com.kirson.corporateapp.services.data.network


internal interface ServiceApi {

}