package com.kirson.corporateapp.services.data

import com.google.firebase.firestore.FirebaseFirestore
import com.kirson.corporateapp.core.data.entity.OrderNM
import com.kirson.corporateapp.core.domain.entity.Order
import com.kirson.corporateapp.services.domain.ServicesRepository
import kotlinx.coroutines.flow.Flow
import javax.inject.Inject

internal class ServicesRepositoryImpl @Inject constructor(
) : ServicesRepository {
  override fun createOrder(): Flow<Order> {
    TODO("Not yet implemented")
  }

}
