# Описание репозитория

Базовый проект для стажровки KODE Start.
[Дизайн](https://www.figma.com/file/NN9GlXCoDOAR5AFKrUAmkl/Skillbox?node-id=33%3A35654), [спецификация api и моки](https://kode-education.stoplight.io/docs/kode-bank/YXBpOjI3Nzc0MTYy-skillbox-auth-api).
