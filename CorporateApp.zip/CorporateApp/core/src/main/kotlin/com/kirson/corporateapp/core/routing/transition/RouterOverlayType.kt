package com.kirson.corporateapp.core.routing.transition

enum class RouterOverlayType {
  None,
  Popup
}
