package com.kirson.corporateapp.core.domain.entity

data class CreateOrderParams(
    val orderId: Order,

)