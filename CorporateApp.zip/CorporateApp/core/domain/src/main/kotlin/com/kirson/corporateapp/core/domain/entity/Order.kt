package com.kirson.corporateapp.core.domain.entity

data class Order(
    val id: String,
    val departmentType: Department.DepartmentType,
    val description: String
)