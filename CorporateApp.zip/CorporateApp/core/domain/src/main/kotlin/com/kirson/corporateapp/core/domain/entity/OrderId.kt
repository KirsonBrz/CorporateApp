package com.kirson.corporateapp.core.domain.entity

@JvmInline
value class OrderId (val value: String)