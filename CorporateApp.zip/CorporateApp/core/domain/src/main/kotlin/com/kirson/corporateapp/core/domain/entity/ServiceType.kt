package com.kirson.corporateapp.core.domain.entity

enum class ServiceType {
  Documents, CreateOrder
}