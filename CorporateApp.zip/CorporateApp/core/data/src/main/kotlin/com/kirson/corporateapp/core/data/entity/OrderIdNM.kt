package com.kirson.corporateapp.core.data.entity

@JvmInline
value class OrderIdNM (val value: String)