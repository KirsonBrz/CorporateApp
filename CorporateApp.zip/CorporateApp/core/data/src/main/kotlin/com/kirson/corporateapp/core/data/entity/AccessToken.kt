package com.kirson.corporateapp.core.data.entity

@JvmInline
value class AccessToken(val value: String)
