package com.kirson.corporateapp.core.data.entity

@JvmInline
value class RefreshToken(val value: String)
