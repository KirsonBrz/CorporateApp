package com.kirson.corporateapp.core.data.entity

@JvmInline
value class GuestToken(val value: String)
