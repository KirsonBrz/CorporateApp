package com.kirson.corporateapp.ui.core.uikit.component.entity

enum class MainSection {
  Services,
  Orders,
  Profile,
}